Polls
=====

.. autoclass:: praw.models.reddit.poll.PollData
    :inherited-members:

.. autoclass:: praw.models.reddit.poll.PollOption
    :inherited-members:

.. include:: ../models/note_dynamically_provided_attributes.txt
