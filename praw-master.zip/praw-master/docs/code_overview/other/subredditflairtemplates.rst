SubredditFlairTemplates
=======================

.. autoclass:: praw.models.reddit.subreddit.SubredditFlairTemplates
    :inherited-members:
