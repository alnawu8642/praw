SubredditCollections
====================

.. autoclass:: praw.models.reddit.collections.SubredditCollections
    :inherited-members:
