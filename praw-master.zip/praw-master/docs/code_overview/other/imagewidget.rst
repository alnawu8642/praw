ImageWidget
===========

.. autoclass:: praw.models.ImageWidget
    :inherited-members:

.. include:: ../models/note_dynamically_provided_attributes.txt
