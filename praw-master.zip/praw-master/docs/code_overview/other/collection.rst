Collection
==========

.. autoclass:: praw.models.Collection
    :inherited-members:

.. include:: ../models/note_dynamically_provided_attributes.txt
