WidgetModeration
================

.. autoclass:: praw.models.WidgetModeration
    :inherited-members:
