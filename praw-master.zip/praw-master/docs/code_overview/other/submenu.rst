Submenu
=======

.. autoclass:: praw.models.Submenu
    :inherited-members:
