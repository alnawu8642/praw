WikiPageModeration
==================

.. autoclass:: praw.models.reddit.wikipage.WikiPageModeration
    :inherited-members:
