CalendarConfiguration
=====================

.. autoclass:: praw.models.CalendarConfiguration
    :inherited-members:
