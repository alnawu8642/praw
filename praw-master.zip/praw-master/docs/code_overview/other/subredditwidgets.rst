SubredditWidgets
================

.. autoclass:: praw.models.SubredditWidgets
    :inherited-members:
