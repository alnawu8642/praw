SubredditLinkFlairTemplates
===========================

.. autoclass:: praw.models.reddit.subreddit.SubredditLinkFlairTemplates
    :inherited-members:
