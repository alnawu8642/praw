CommentModeration
=================

.. autoclass:: praw.models.reddit.comment.CommentModeration
    :inherited-members:
