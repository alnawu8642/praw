InlineVideo
===========

.. autoclass:: praw.models.InlineVideo
    :inherited-members:
