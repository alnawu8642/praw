SubredditWidgetsModeration
==========================

.. autoclass:: praw.models.SubredditWidgetsModeration
    :inherited-members:
