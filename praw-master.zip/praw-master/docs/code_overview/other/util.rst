Util
====

.. autoclass:: praw.models.util.BoundedSet
    :inherited-members:

.. autoclass:: praw.models.util.ExponentialCounter
    :inherited-members:

.. autofunction:: praw.models.util.permissions_string

.. autofunction:: praw.models.util.stream_generator
