Hover
=====

.. autoclass:: praw.models.Hover
    :inherited-members:
