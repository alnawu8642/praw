ModmailConversation
===================

.. autoclass:: praw.models.reddit.modmail.ModmailConversation
    :inherited-members:

.. include:: note_dynamically_provided_attributes.txt
