LiveUpdate
==========

.. autoclass:: praw.models.LiveUpdate
    :inherited-members:

.. include:: note_dynamically_provided_attributes.txt
